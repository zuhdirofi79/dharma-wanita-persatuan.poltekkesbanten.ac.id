<?php

namespace App\Models;

use App\Enums\FileCategory;
use App\Enums\SubmissionStatus;
use App\Enums\UploadedBy;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Submission extends Model
{
    protected $fillable = [
        'ticket_number',
        'progress_token',
        'service_type_id',
        'study_program_id',
        'nim',
        'full_name',
        'nik',
        'email',
        'whatsapp',
        'semester',
        'gpa_score',
        'mother_name',
        'request_type',
        'corrected_data',
        'purpose',
        'issue_type',
        'leave_reason',
        'exit_reason',
        'entry_year',
        'graduation_year',
        'alumni_letter_type',
        'certificate_number',
        'activity_name',
        'activity_date',
        'activity_location',
        'participant_list',
        'previous_status',
        'reactivation_reason',
        'additional_note',
        'status',
        'admin_note',
        'jurusan_verified_at',
        'jurusan_verified_by',
        'jurusan_verification_note',
        'central_verified_at',
        'central_verified_by',
        'central_verification_note',
        'ready_to_send_email',
        'email_sent_at',
        'email_error',
        'data_confirmed',
    ];

    protected function casts(): array
    {
        return [
            'gpa_score' => 'decimal:2',
            'activity_date' => 'date',
            'ready_to_send_email' => 'boolean',
            'email_sent_at' => 'datetime',
            'jurusan_verified_at' => 'datetime',
            'central_verified_at' => 'datetime',
            'data_confirmed' => 'boolean',
        ];
    }

    public function serviceType(): BelongsTo
    {
        return $this->belongsTo(ServiceType::class);
    }

    public function studyProgram(): BelongsTo
    {
        return $this->belongsTo(StudyProgram::class);
    }

    public function files(): HasMany
    {
        return $this->hasMany(SubmissionFile::class);
    }

    public function statusHistories(): HasMany
    {
        return $this->hasMany(StatusHistory::class);
    }

    public function jurusanVerifiedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'jurusan_verified_by');
    }

    public function centralVerifiedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'central_verified_by');
    }

    public function applicantFiles(): HasMany
    {
        return $this->files()->where('uploaded_by', UploadedBy::Applicant->value);
    }

    public function finalFiles(): HasMany
    {
        return $this->files()->where('file_category', FileCategory::FinalResult->value);
    }

    public function hasFinalFiles(): bool
    {
        return $this->finalFiles()->exists();
    }

    public function isCompleted(): bool
    {
        return $this->status === SubmissionStatus::Completed->value;
    }

    public function canDownloadResults(): bool
    {
        return in_array($this->status, [
            SubmissionStatus::Completed->value,
            SubmissionStatus::EmailSent->value,
        ], true) && $this->hasFinalFiles();
    }

    public function satisfactionSurveys(): HasMany
    {
        return $this->hasMany(AcademicSatisfactionSurvey::class);
    }

    public function satisfactionSurvey(): HasOne
    {
        return $this->hasOne(AcademicSatisfactionSurvey::class)->latestOfMany();
    }

    public function hasSatisfactionSurvey(): bool
    {
        return AcademicSatisfactionSurvey::query()
            ->where(function ($query) {
                $query->where('submission_id', $this->id);

                if (filled($this->ticket_number)) {
                    $query->orWhere('ticket_number', $this->ticket_number);
                }
            })
            ->exists();
    }

    public function requiresSatisfactionSurveyBeforeDownload(): bool
    {
        return $this->canDownloadResults() && ! $this->hasSatisfactionSurvey();
    }

    public function canPublicDownloadFinal(): bool
    {
        return $this->canDownloadResults() && $this->hasSatisfactionSurvey();
    }

    public function requiresSkVerification(): bool
    {
        return in_array($this->serviceType?->slug, [
            'surat-cuti-mahasiswa',
            'surat-keluar-mahasiswa',
        ], true);
    }
}
