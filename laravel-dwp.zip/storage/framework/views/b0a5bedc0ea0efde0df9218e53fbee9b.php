<section class="service-reminder-section wisuda-home-cta" style="padding-top:0;">
    <div class="container">
        <div class="service-reminder-banner" style="background:#fff7ed;border-color:#fdba74;">
            <h2 class="service-reminder-title">Wisuda</h2>
            <p class="service-reminder-text">
                Informasi ketentuan wisuda dan pemesanan toga wisuda Poltekkes Kemenkes Banten.
            </p>
            <div class="service-reminder-actions">
                <a href="<?php echo e(route('wisuda.index')); ?>" class="btn-sm btn-teal">Lihat Informasi Wisuda</a>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/u708283844/domains/dharma-wanita-persatuan.poltekkesbanten.ac.id/laravel-dwp/resources/views/partials/wisuda-cta.blade.php ENDPATH**/ ?>