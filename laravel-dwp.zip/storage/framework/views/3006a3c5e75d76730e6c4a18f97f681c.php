<footer class="site-footer">
    <div class="container">
        <p>© Copyright Layanan Akademik Poltekkes Kemenkes Banten</p>
        <p>
            Unit Teknologi Informasi ·
            <a href="<?php echo e(route('survey.create')); ?>" class="site-footer-admin-link">Isi Survei Kepuasan</a>
            ·
            <a href="<?php echo e(route('admin.login')); ?>" class="site-footer-admin-link">Login Admin</a>
        </p>
    </div>
</footer>
<?php /**PATH /home/u708283844/domains/dharma-wanita-persatuan.poltekkesbanten.ac.id/laravel-dwp/resources/views/partials/footer.blade.php ENDPATH**/ ?>