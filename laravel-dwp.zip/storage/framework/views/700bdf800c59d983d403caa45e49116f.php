<?php
    $queueUrl = route('queues.index');
?>
<section class="service-reminder-section" style="padding-top:0;">
    <div class="container">
        <div class="service-reminder-banner" style="background:#eff6ff;border-color:#93c5fd;">
            <h2 class="service-reminder-title">Antrean Layanan Akademik</h2>
            <p class="service-reminder-text">
                Ambil nomor antrean untuk pelayanan langsung di ruang layanan akademik.
            </p>
            <div class="service-reminder-actions">
                <a href="<?php echo e($queueUrl); ?>" class="btn-sm btn-blue">Ambil Nomor Antrean</a>
                <a href="<?php echo e(route('queues.display')); ?>" class="btn-sm btn-gray" target="_blank">Lihat Display</a>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/u708283844/domains/dharma-wanita-persatuan.poltekkesbanten.ac.id/laravel-dwp/resources/views/partials/queue-cta.blade.php ENDPATH**/ ?>