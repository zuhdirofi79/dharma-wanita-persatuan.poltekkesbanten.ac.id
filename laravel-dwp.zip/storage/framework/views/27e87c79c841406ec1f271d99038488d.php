<header class="site-header">
    <div class="container site-header-inner">
        <a href="<?php echo e(route('beranda')); ?>" class="site-brand site-brand-logo-only" aria-label="Beranda Layanan Akademik Poltekkes Kemenkes Banten">
            <img src="<?php echo e(asset('src/img/logo.png')); ?>" alt="Logo Poltekkes Kemenkes Banten" class="site-brand-logo site-logo">
        </a>

        <nav class="site-nav">
            <a href="<?php echo e(route('beranda')); ?>" class="site-nav-link <?php echo e(request()->routeIs('beranda') ? 'active' : ''); ?>">Home</a>

            <div class="site-nav-dropdown">
                <button type="button" class="site-nav-link site-nav-dropdown-toggle <?php echo e(request()->is('layanan/*') ? 'active' : ''); ?>">
                    Layanan Akademik
                    <span>▾</span>
                </button>
                <div class="site-nav-dropdown-menu">
                    <?php $__currentLoopData = $navServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/layanan/' . $service->slug)); ?>"><?php echo e($service->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <a href="<?php echo e(route('progress.index')); ?>" class="site-nav-link <?php echo e(request()->routeIs('progress.*') ? 'active' : ''); ?>">Progres Layanan</a>
            <a href="<?php echo e(route('queues.index')); ?>" class="site-nav-link <?php echo e(request()->routeIs('queues.*') ? 'active' : ''); ?>">Antrean Layanan</a>
            <a href="<?php echo e(route('survey.create')); ?>" class="site-nav-link <?php echo e(request()->routeIs('survey.*') ? 'active' : ''); ?>">Survei Kepuasan</a>
            <a href="<?php echo e(route('about')); ?>" class="site-nav-link <?php echo e(request()->routeIs('about', 'tentang') ? 'active' : ''); ?>">Tentang</a>
            <a href="<?php echo e(route('wisuda.index')); ?>" class="site-nav-link <?php echo e(request()->routeIs('wisuda.*') ? 'active' : ''); ?>">Wisuda</a>
            <a href="https://poltekkesbanten.ac.id" target="_blank" rel="noopener" class="site-nav-button poltekkes-button institution-button">POLTEKKES KEMENKES BANTEN</a>
            <a href="<?php echo e(route('admin.login')); ?>" class="site-admin-login">Login Admin</a>
        </nav>
    </div>
</header>
<?php /**PATH /home/u708283844/domains/dharma-wanita-persatuan.poltekkesbanten.ac.id/laravel-dwp/resources/views/partials/navbar.blade.php ENDPATH**/ ?>