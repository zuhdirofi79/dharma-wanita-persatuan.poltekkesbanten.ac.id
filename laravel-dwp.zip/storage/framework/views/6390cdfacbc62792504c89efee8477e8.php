<?php
    $adminEmail = config('akademik.admin_contact_email');
?>
<section class="service-reminder-section">
    <div class="container">
        <div class="service-reminder-banner">
            <h2 class="service-reminder-title">Sudah Mengajukan Layanan?</h2>
            <p class="service-reminder-text">
                Bagi mahasiswa aktif dan alumni yang sudah mengajukan layanan akademik, mohon untuk selalu mengecek Progres Layanan secara berkala dan memeriksa email yang digunakan saat pengajuan. File hasil layanan akan dikirimkan melalui email setelah proses selesai.
            </p>
            <p class="service-reminder-note">
                Jika email belum masuk, silakan cek folder Spam/Junk/Promotion atau hubungi admin layanan akademik melalui email.
            </p>
            <div class="service-reminder-actions">
                <a href="<?php echo e(route('progress.index')); ?>" class="btn-sm btn-teal">Cek Progres Layanan</a>
                <a href="<?php echo e(route('survey.create')); ?>" class="btn-sm btn-blue">Isi Survei Kepuasan</a>
                <a href="mailto:<?php echo e($adminEmail); ?>" class="btn-sm btn-green">Hubungi Admin via Email</a>
                <a href="mailto:<?php echo e($adminEmail); ?>" class="service-reminder-email"><?php echo e($adminEmail); ?></a>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/u708283844/domains/dharma-wanita-persatuan.poltekkesbanten.ac.id/laravel-dwp/resources/views/partials/service-reminder-beranda.blade.php ENDPATH**/ ?>