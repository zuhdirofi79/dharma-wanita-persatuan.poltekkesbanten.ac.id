<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Layanan Akademik Poltekkes Kemenkes Banten'); ?></title>
    <link rel="stylesheet" href="<?php echo e(env('CSS_URL', asset('css/akademik.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/navbar-fix.css')); ?>?v=20260904-nav2">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(session('success')): ?>
        <div class="container" style="padding-top:1rem;">
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(session('warning')): ?>
        <div class="container" style="padding-top:1rem;">
            <div class="alert alert-error"><?php echo e(session('warning')); ?></div>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="container" style="padding-top:1rem;">
            <div class="alert alert-error"><?php echo e(session('error')); ?></div>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <button type="button" class="back-to-top" id="backToTop" aria-label="Kembali ke atas">↑</button>

    <script>
        const backToTop = document.getElementById('backToTop');
        window.addEventListener('scroll', () => {
            backToTop.classList.toggle('show', window.scrollY > 300);
        });
        backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/u708283844/domains/dharma-wanita-persatuan.poltekkesbanten.ac.id/laravel-dwp/resources/views/layouts/app.blade.php ENDPATH**/ ?>